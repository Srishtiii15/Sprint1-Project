package capgemini.emp_asset;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeAssetManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeAssetManagementSystemApplication.class, args);
	}

}
