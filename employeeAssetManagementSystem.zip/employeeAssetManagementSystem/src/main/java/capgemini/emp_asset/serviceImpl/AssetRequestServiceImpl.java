package capgemini.emp_asset.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import capgemini.emp_asset.dao.IAssetRequestRepository;
import capgemini.emp_asset.entity.AssetRequest;
import capgemini.emp_asset.exception.DuplicateAssetRequestException;
import capgemini.emp_asset.service.IAssetRequestService;

@Service
public class AssetRequestServiceImpl implements IAssetRequestService{

	@Autowired IAssetRequestRepository requestRepository;
	
	@Override
	public List<AssetRequest> getAllAssetRequest() {
		return requestRepository.findAll();
	}

	@Override
	public Optional<AssetRequest> getAssetRequest(int assetRequestId) {
		return requestRepository.findById(assetRequestId);
	}

	@Override
	public AssetRequest addAssetRequest(AssetRequest assetRequest) {
		if(requestRepository.existsById(assetRequest.getAssetReqId())) {
			throw new DuplicateAssetRequestException("No duplicate asset Request");
		}
		AssetRequest addReq = requestRepository.save(assetRequest);
		return addReq;
	}
	
	
	@Override
	public void removeAssetRequest(AssetRequest asset) {
		requestRepository.delete(asset);
	}

	@Override
	public AssetRequest editAssetRequest(AssetRequest assetRequest) {
		return requestRepository.save(assetRequest);
		
	}

}
