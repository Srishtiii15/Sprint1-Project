package capgemini.emp_asset.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import capgemini.emp_asset.dao.IEmployeeRepository;
import capgemini.emp_asset.entity.Employee;
import capgemini.emp_asset.service.IEmployeeService;

@Service
public class EmployeeServiceImpl implements IEmployeeService {

	@Autowired
	private IEmployeeRepository employeeRepository;

	@Override
	public List<Employee> getAllEmployee() {
		return employeeRepository.findAll();
	}

	@Override
	public Optional<Employee> getEmployee(int employeeId) {
		return employeeRepository.findById(employeeId);
	}

	@Override
	public Employee addEmployee(Employee employee) {
		return employeeRepository.save(employee);
	}

	@Override
	public void removeEmployee(Employee emp) {
		employeeRepository.delete(emp);
	}

	@Override
	public Employee editEmployee(Employee employee) {
		return employeeRepository.save(employee);
		
	} 
	
	
}
