package capgemini.emp_asset.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import capgemini.emp_asset.dao.IAssetRepository;
import capgemini.emp_asset.entity.Asset;
import capgemini.emp_asset.service.IAssetService;

@Service
public class AssetServiceImpl implements IAssetService{

	@Autowired
	private IAssetRepository iAssetRepository;
	
	@Override
	public List<Asset> getAllAssets() {
		return iAssetRepository.findAll();
	}

	@Override
	public Optional<Asset> getAsset(int assetId) {
		return iAssetRepository.findById(assetId);
	}

	@Override
	public Asset addAsset(Asset asset) {
		return iAssetRepository.save(asset);	
	}

	@Override
	public void removeAsset(Asset asset) {
		iAssetRepository.delete(asset);
	}

	@Override
	public Asset editAsset(Asset asset) {
		return iAssetRepository.save(asset);
	}
	
}
