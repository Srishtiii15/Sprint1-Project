package capgemini.emp_asset.serviceImpl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import capgemini.emp_asset.dao.IUserRepository;
import capgemini.emp_asset.entity.User;
import capgemini.emp_asset.exception.UserNotFoundException;
import capgemini.emp_asset.service.IUserService;

@Service
public class UserServiceImpl implements IUserService {
   
    @Autowired
    private IUserRepository UserRepository;

 

    @Override
    public String validateUser(String username, String password) throws UserNotFoundException {    
        User user = UserRepository.findByUsernameAndPassword(username,password);
        String message=null;
        if(user!=null) {
        	message="Valid User";
        }
        else {
        	throw new UserNotFoundException("Invalid User");
        }
        return message;
    }

 

    @Override
    public User addUser(User user) {
        User us= UserRepository.save(user);
        return us;
    }

 

    @Override
    public User removeUser(User user) {
        
        Optional<User> us = UserRepository.findById(user.getUserId());
        User u= null;
        if (us.isPresent()) {
            u = us.get();
        }
        UserRepository.delete(u);
        return u;

 

    }
 }
 
