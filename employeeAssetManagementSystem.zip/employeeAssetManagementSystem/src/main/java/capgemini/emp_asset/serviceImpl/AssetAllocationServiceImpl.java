package capgemini.emp_asset.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import capgemini.emp_asset.dao.IAssetAllocationRepository;
import capgemini.emp_asset.entity.Asset;
import capgemini.emp_asset.entity.AssetAllocation;
import capgemini.emp_asset.entity.AssetRequest;
import capgemini.emp_asset.exception.DuplicateAssetAllocationException;
import capgemini.emp_asset.exception.DuplicateAssetRequestException;
import capgemini.emp_asset.service.IAssetAllocationService;

@Service
public class AssetAllocationServiceImpl implements IAssetAllocationService {

	@Autowired 
	private IAssetAllocationRepository assetAllocationRepository;
	
	@Override
	public List<AssetAllocation> getAllAssetAllocation() {
		return assetAllocationRepository.findAll();
	}

	@Override
	public Optional<AssetAllocation> getAssetAllocation(int assetAllocationId) {
		return assetAllocationRepository.findById(assetAllocationId);
	}

	@Override
	public AssetAllocation addAssetAllocation(AssetAllocation assetAllocation){
		if(assetAllocationRepository.existsById(assetAllocation.getassetAllocationId())) {
			throw new DuplicateAssetAllocationException("No duplicate asset allocation");
		}
		AssetAllocation addAllocation = assetAllocationRepository.save(assetAllocation);
		return addAllocation;
	}
	
	

	@Override
	public void removeAssetAllocation(AssetAllocation asset) {
		assetAllocationRepository.delete(asset);
	}

	@Override
	public AssetAllocation editAssetAllocation(AssetAllocation assetAllocation) {
		return assetAllocationRepository.save(assetAllocation);
		
	}

}
