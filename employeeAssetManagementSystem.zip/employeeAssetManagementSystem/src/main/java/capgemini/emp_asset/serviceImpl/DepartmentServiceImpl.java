package capgemini.emp_asset.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import capgemini.emp_asset.dao.IDepartmentRepository;
import capgemini.emp_asset.entity.Department;
import capgemini.emp_asset.service.IDepartmentService;

@Service
public class DepartmentServiceImpl implements IDepartmentService{

	@Autowired
	private IDepartmentRepository departmentRepository;

	@Override
	public List<Department> getAllDepartment() {
		return departmentRepository.findAll();
	}

	@Override
	public Optional<Department> getDepartment(int departmentId) {
		return departmentRepository.findById(departmentId);
	}

	@Override
	public Department addDepartment(Department department) {
		return departmentRepository.save(department);
		
	}

	@Override
	public void removeDepartment(Department dept) {
		departmentRepository.delete(dept);
	}

	@Override
	public Department editDepartment(Department department) {
		return departmentRepository.save(department);
		
	}

	
}
