package capgemini.emp_asset.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import capgemini.emp_asset.entity.User;
import capgemini.emp_asset.exception.UserNotFoundException;
import capgemini.emp_asset.service.IUserService;

@RestController
public class UserController {
	@Autowired
	private IUserService userService;
 
	//Validate user with the help of username and password
    @RequestMapping(value = "/validateUser/{username}/{password}", method = RequestMethod.GET)
    public String validateUser(@PathVariable String username,@PathVariable String password) throws UserNotFoundException {
        String us = userService.validateUser(username, password);
        return us;
    }

 
    //add user into DB.
    @RequestMapping(value = "/addUser", method = RequestMethod.POST)
    public User adduser(@RequestBody User user) {
        User us = userService.addUser(user);
        return us;
    }

 
    //Remove user from DB.
    @RequestMapping(value = "/removeUser", method = RequestMethod.DELETE)
    public User removeuser(@RequestBody User user) throws UserNotFoundException{
        User us = userService.removeUser(user);
        return us;
    }

 

}

