package capgemini.emp_asset.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import capgemini.emp_asset.entity.AssetAllocation;
import capgemini.emp_asset.exception.AssetAllocationNotFoundException;
import capgemini.emp_asset.exception.DuplicateAssetAllocationException;
import capgemini.emp_asset.service.IAssetAllocationService;

@RestController
public class AssetAllocationController {

	@Autowired
	private IAssetAllocationService assetAllocationService;
	
		//Insert asset allocation data in database
		@PostMapping(value="/assetAllocation/insert")
		public ResponseEntity createAssetAllocation(@Valid @RequestBody AssetAllocation asset)throws DuplicateAssetAllocationException {
			AssetAllocation assetAll = assetAllocationService.addAssetAllocation(asset);
			return new ResponseEntity<>(assetAll,HttpStatus.CREATED);
		}
		
		
		//Retrieve all asset allocation data from database
		@GetMapping(value="/getAllAssetAllocation/all")
		public List<AssetAllocation> getAllAssetAllocations()
		{
			return assetAllocationService.getAllAssetAllocation();
		}
		
		//Retrieve asset allocation data by ID from database
		@RequestMapping(value="/getAssetAllocation/get/{assetAllocationId}", method=RequestMethod.GET)
		public ResponseEntity<AssetAllocation>getAssetAllocation(@PathVariable int assetAllocationId) throws AssetAllocationNotFoundException{
			AssetAllocation assetAll = assetAllocationService.getAssetAllocation(assetAllocationId).orElseThrow(()-> new AssetAllocationNotFoundException("No asset allocation with that id "+assetAllocationId));
			return ResponseEntity.ok().body(assetAll);
		}
		
		//Update asset allocation data in database
		@RequestMapping(value="/assetAllocation/update", method=RequestMethod.PUT)
		public AssetAllocation updateAssetAllocation(@RequestBody AssetAllocation asset) {
			AssetAllocation assets = assetAllocationService.editAssetAllocation(asset);
			return assets;
		}
		
		//Delete
		@DeleteMapping("/assetAllocation/delete/{assetAllocationId}")
		public ResponseEntity<AssetAllocation> removeAssetAllocation(@PathVariable("assetAllocationId")Integer assetAllocationId) throws AssetAllocationNotFoundException{
			AssetAllocation ass= assetAllocationService.getAssetAllocation(assetAllocationId).orElseThrow(()-> new AssetAllocationNotFoundException("Asset Not Found With this Id:"+assetAllocationId));
			assetAllocationService.removeAssetAllocation(ass);
			return ResponseEntity.ok(null);
		}
}
