package capgemini.emp_asset.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import capgemini.emp_asset.entity.Department;
import capgemini.emp_asset.exception.DepartmentNotFoundException;
import capgemini.emp_asset.service.IDepartmentService;

@RestController
public class DepartmentController {
	@Autowired
	private IDepartmentService departmentService;
	
	//Insert Department in DB
	@PostMapping(value="/department/insert")
	public Department createDepartment(@Valid @RequestBody Department department) {
		return departmentService.addDepartment(department);
	}
	
	//Retrieves all Department from db
		@GetMapping(value="/getAllDepartment/all")
		public List<Department> getAllDepartment()
		{
			return departmentService.getAllDepartment();
		}
	
	//Retrieve specific department record from DB
	@RequestMapping(value="/getDepartment/get/{deptId}", method=RequestMethod.GET)
	public ResponseEntity<Department> getDepartment(@PathVariable int deptId) throws DepartmentNotFoundException{
		Department dept = departmentService.getDepartment(deptId).orElseThrow(()-> new DepartmentNotFoundException("No department with this id "+deptId));
		return ResponseEntity.ok().body(dept);
	}
	
	//Updates existing department details using provided Department id
	@RequestMapping(value="/department/update", method=RequestMethod.PUT)
	public Department updateEmployee(@RequestBody Department department) {
		Department dept = departmentService.editDepartment(department);
		return dept;
	}
	
	//Deletes department record using Department id
	@DeleteMapping("/department/delete/{deptId}")
	public ResponseEntity<Department> removeDepartment(@PathVariable("deptId")Integer deptId) throws DepartmentNotFoundException{
		Department dept= departmentService.getDepartment(deptId).orElseThrow(()-> new DepartmentNotFoundException("Department Not Found With this Id:"+deptId));
		departmentService.removeDepartment(dept);
		return ResponseEntity.ok(null);
	}
	
	
}
