package capgemini.emp_asset.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import capgemini.emp_asset.entity.Employee;
import capgemini.emp_asset.exception.EmployeeNotFoundException;
import capgemini.emp_asset.service.IEmployeeService;

@RestController
public class EmployeeController {
	@Autowired
	private IEmployeeService employeeService;
	
	//Inserts new employee in db
	@PostMapping(value="/employee/insert")
	public Employee createEmployee(@Valid @RequestBody Employee employee) { 
		return employeeService.addEmployee(employee);
	}
	
	//Retrieves specific employee from db
	@RequestMapping(value="/getEmployee/get/{empId}", method=RequestMethod.GET)
	public ResponseEntity<Employee> getEmployee(@PathVariable int empId) throws EmployeeNotFoundException{
		Employee emp = employeeService.getEmployee(empId).orElseThrow(()->new EmployeeNotFoundException("No employee found with this id "+empId));
		return ResponseEntity.ok(emp);
	}
	
	//Retrieves all employees from db
	@GetMapping(value="/getAllEmployee/all")
	public List<Employee> getAllEmployees()
	{
		return employeeService.getAllEmployee();
	}
	
	
	//Updates existing employee details using provided employee id
	@RequestMapping(value="/employee/update", method=RequestMethod.PUT)
	public Employee updateEmployee(@RequestBody Employee employee) {
		Employee emp = employeeService.editEmployee(employee);
		return emp;
	}
	
	
	//Deletes an Department record using employee id
	@DeleteMapping("/employee/delete/{empId}")
	public ResponseEntity<Employee> removeEmployee(@PathVariable("empId")Integer empId) throws EmployeeNotFoundException{
		Employee emp= employeeService.getEmployee(empId).orElseThrow(()-> new EmployeeNotFoundException("Employee Not Found With this Id:"+empId));
		employeeService.removeEmployee(emp);
		return ResponseEntity.ok(null);
	}
	
}
