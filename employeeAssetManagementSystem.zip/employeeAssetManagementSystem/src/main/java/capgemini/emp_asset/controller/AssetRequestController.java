package capgemini.emp_asset.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import capgemini.emp_asset.entity.AssetRequest;
import capgemini.emp_asset.exception.AssetRequestNotFoundException;
import capgemini.emp_asset.exception.DuplicateAssetRequestException;
import capgemini.emp_asset.service.IAssetRequestService;

@RestController
public class AssetRequestController {
	@Autowired
	private IAssetRequestService assetRequestService;
	
	//Insert Asset request in DB.
	@PostMapping(value="/assetRequest/insert")
	public ResponseEntity createAssetRequest(@Valid @RequestBody AssetRequest req) throws DuplicateAssetRequestException { 
		AssetRequest assetReq = assetRequestService.addAssetRequest(req);
		return new ResponseEntity<>(assetReq,HttpStatus.CREATED);
	}
	
	
	//Retrieves specific Asset Request from db
	@RequestMapping(value="/getAssetRequest/get/{assetReqId}", method=RequestMethod.GET)
	public ResponseEntity<AssetRequest> getAssetRequest(@PathVariable int assetReqId) throws AssetRequestNotFoundException {
		AssetRequest ass = assetRequestService.getAssetRequest(assetReqId).orElseThrow(()-> new AssetRequestNotFoundException("No asset request found with this id "+assetReqId));
		return ResponseEntity.ok(ass);
	}
	
	//Retrieves all Asset Requests from db
	@GetMapping(value="/getAllAssetRequest/all")
	public List<AssetRequest> getAllAssetRequest()
	{
		return assetRequestService.getAllAssetRequest();
	}
	
	
	//Update asset request
	@RequestMapping(value="/assetRequest/update", method=RequestMethod.PUT)
	public AssetRequest updateAssetRequest(@RequestBody AssetRequest asset) {
		AssetRequest assets = assetRequestService.editAssetRequest(asset);
		return assets;
	}
	
	
	//Delete asset request
	@DeleteMapping("/assetReq/delete/{assetReqId}")
	public ResponseEntity<AssetRequest> removeAsset(@PathVariable("assetReqId")Integer assetReqId) throws AssetRequestNotFoundException{
		AssetRequest ass= assetRequestService.getAssetRequest(assetReqId).orElseThrow(()-> new AssetRequestNotFoundException("Asset request Not Found With this Id:"+assetReqId));
		assetRequestService.removeAssetRequest(ass);
		return ResponseEntity.ok(null);
	}
	
}
