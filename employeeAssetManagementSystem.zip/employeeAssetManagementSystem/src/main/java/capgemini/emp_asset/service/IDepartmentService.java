package capgemini.emp_asset.service;

import java.util.List;
import java.util.Optional;

import capgemini.emp_asset.entity.Department;

public interface IDepartmentService {

	List<Department> getAllDepartment();
	Optional<Department> getDepartment(int departmentId);
	Department addDepartment(Department department);
	void removeDepartment(Department dept);
	Department editDepartment(Department department);
	
}
