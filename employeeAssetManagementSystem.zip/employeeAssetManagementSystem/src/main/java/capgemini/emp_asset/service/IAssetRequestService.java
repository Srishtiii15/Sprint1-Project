package capgemini.emp_asset.service;

import java.util.List;
import java.util.Optional;

import capgemini.emp_asset.entity.AssetRequest;
import capgemini.emp_asset.exception.DuplicateAssetRequestException;


public interface IAssetRequestService {

	List<AssetRequest> getAllAssetRequest();
	Optional<AssetRequest> getAssetRequest(int assetRequestId);
	AssetRequest addAssetRequest(AssetRequest assetRequest)throws DuplicateAssetRequestException;
	void removeAssetRequest(AssetRequest asset);
	AssetRequest editAssetRequest(AssetRequest assetRequest);
	
}
