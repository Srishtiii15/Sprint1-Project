package capgemini.emp_asset.service;

import java.util.List;
import java.util.Optional;

import capgemini.emp_asset.entity.Asset;

public interface IAssetService {

	List<Asset> getAllAssets();
	Optional<Asset> getAsset(int assetId);
	Asset addAsset(Asset asset);
	void removeAsset(Asset ass);
	Asset editAsset(Asset asset);

}
