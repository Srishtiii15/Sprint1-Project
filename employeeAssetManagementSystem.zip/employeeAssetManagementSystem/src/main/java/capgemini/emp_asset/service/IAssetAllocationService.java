package capgemini.emp_asset.service;

import java.util.List;
import java.util.Optional;

import capgemini.emp_asset.entity.AssetAllocation;
import capgemini.emp_asset.exception.DuplicateAssetAllocationException;


public interface IAssetAllocationService {
	
	List<AssetAllocation> getAllAssetAllocation();
	Optional<AssetAllocation> getAssetAllocation(int assetAllocationId);
	AssetAllocation addAssetAllocation(AssetAllocation assetAllocation) throws DuplicateAssetAllocationException;
	void removeAssetAllocation(AssetAllocation ass);
	AssetAllocation editAssetAllocation(AssetAllocation assetAllocation);

}
