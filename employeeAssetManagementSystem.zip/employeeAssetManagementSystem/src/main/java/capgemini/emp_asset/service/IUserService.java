package capgemini.emp_asset.service;

import capgemini.emp_asset.entity.User;
import capgemini.emp_asset.exception.UserNotFoundException;

public interface IUserService {

		String validateUser(String username, String password) throws UserNotFoundException;
	    public User addUser(User user);
	    public User removeUser(User user);
	
}
