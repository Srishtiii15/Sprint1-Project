package capgemini.emp_asset.service;

import java.util.List;
import java.util.Optional;

import capgemini.emp_asset.entity.Employee;

public interface IEmployeeService {

	List<Employee> getAllEmployee();
	Optional<Employee> getEmployee(int employeeId);
	Employee addEmployee(Employee employee);
	void removeEmployee(Employee emp);
	Employee editEmployee(Employee employee);
    
}
