package capgemini.emp_asset.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import capgemini.emp_asset.entity.AssetAllocation;

public interface IAssetAllocationRepository extends JpaRepository<AssetAllocation, Integer>{

}
