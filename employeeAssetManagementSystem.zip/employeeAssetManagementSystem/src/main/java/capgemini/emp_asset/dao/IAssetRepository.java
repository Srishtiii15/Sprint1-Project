package capgemini.emp_asset.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import capgemini.emp_asset.entity.Asset;

public interface IAssetRepository extends JpaRepository<Asset, Integer>{

}
