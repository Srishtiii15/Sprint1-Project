package capgemini.emp_asset.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import capgemini.emp_asset.entity.AssetRequest;

public interface IAssetRequestRepository extends JpaRepository<AssetRequest, Integer>{

}
