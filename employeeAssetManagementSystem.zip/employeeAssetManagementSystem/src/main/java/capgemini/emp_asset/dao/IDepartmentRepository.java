package capgemini.emp_asset.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import capgemini.emp_asset.entity.Department;

public interface IDepartmentRepository extends JpaRepository<Department, Integer> {

}
