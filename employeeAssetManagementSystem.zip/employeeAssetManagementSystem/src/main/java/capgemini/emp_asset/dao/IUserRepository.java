package capgemini.emp_asset.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import capgemini.emp_asset.entity.User;

public interface IUserRepository extends JpaRepository<User, Integer>{

	User findByUsernameAndPassword(String username, String password);

}
