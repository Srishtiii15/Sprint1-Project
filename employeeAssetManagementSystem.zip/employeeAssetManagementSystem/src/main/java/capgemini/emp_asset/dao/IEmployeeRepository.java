package capgemini.emp_asset.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import capgemini.emp_asset.entity.Employee;

@Repository
public interface IEmployeeRepository extends JpaRepository<Employee,Integer> {
	
	
}
