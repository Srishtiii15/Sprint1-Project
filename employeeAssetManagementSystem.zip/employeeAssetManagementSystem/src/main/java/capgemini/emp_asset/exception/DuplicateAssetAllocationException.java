package capgemini.emp_asset.exception;

public class DuplicateAssetAllocationException extends RuntimeException{
	
	private String message;
    public DuplicateAssetAllocationException(String message) {
        super(message);
        this.message = message;
    }
    public DuplicateAssetAllocationException() {
    }

}
