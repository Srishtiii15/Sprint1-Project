package capgemini.emp_asset.exception;

import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

@ControllerAdvice
public class GlobalExceptionHandler {

	//In case user is not found
	@ExceptionHandler(AssetNotFoundException.class)
	 public ResponseEntity<?> UserNotFoundException(AssetNotFoundException ex, WebRequest request) {
        ErrorDetails errorDetails = new ErrorDetails(new Date(), ex.getMessage(), request.getDescription(false));
        return new ResponseEntity<>(errorDetails, HttpStatus.NOT_FOUND);
   }
  
		//In case order is not found
		@ExceptionHandler(AssetAllocationNotFoundException.class)
		 public ResponseEntity<?> OrderNotFoundException(AssetAllocationNotFoundException ex, WebRequest request) {
		       ErrorDetails errorDetails = new ErrorDetails(new Date(), ex.getMessage(), request.getDescription(false));
		       return new ResponseEntity<>(errorDetails, HttpStatus.NOT_FOUND);
		   }
	
		//In case address is not found
		@ExceptionHandler(AssetRequestNotFoundException.class)
		 public ResponseEntity<?> AddressNotFoundException(AssetRequestNotFoundException ex, WebRequest request) {
	        ErrorDetails errorDetails = new ErrorDetails(new Date(), ex.getMessage(), request.getDescription(false));
	        return new ResponseEntity<>(errorDetails, HttpStatus.NOT_FOUND);
	   }
	  
		//In case customer is not found
		@ExceptionHandler(DepartmentNotFoundException.class)
		public ResponseEntity<?> CustomerNotFoundException(DepartmentNotFoundException ex, WebRequest request){
			ErrorDetails errorDetails= new ErrorDetails(new Date(),ex.getMessage(),request.getDescription(false));
			return new ResponseEntity<>(errorDetails,HttpStatus.NOT_FOUND);
		}
		
		
		@ExceptionHandler(EmployeeNotFoundException.class)
		public ResponseEntity<?>ProductNotFoundException(EmployeeNotFoundException ex,WebRequest request)
		{
			ErrorDetails errorDetails=new ErrorDetails(new Date(),ex.getMessage(),request.getDescription(false));
			return new ResponseEntity<>(errorDetails, HttpStatus.NOT_FOUND);
		}
		
		@ExceptionHandler(UserNotFoundException.class)
		public ResponseEntity<?>CategoryNotFoundException(UserNotFoundException ex,WebRequest request)
		{
			ErrorDetails errorDetails=new ErrorDetails(new Date(),ex.getMessage(),request.getDescription(false));
			return new ResponseEntity<>(errorDetails, HttpStatus.NOT_FOUND);
		}
		
	
	//In case any other exception occurs
   @ExceptionHandler(Exception.class)
   public ResponseEntity<?> globalExcpetionHandler(Exception ex, WebRequest request) {
       ErrorDetails errorDetails = new ErrorDetails(new Date(), ex.getMessage(), request.getDescription(false));
       return new ResponseEntity<>(errorDetails, HttpStatus.INTERNAL_SERVER_ERROR);
   }
	
}

