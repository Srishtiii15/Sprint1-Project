package capgemini.emp_asset.exception;

public class DuplicateAssetRequestException extends RuntimeException{
	private String message;
    public DuplicateAssetRequestException(String message) {
        super(message);
        this.message = message;
    }
    public DuplicateAssetRequestException() {
    }

}
